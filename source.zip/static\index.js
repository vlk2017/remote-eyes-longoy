const createButton = document.querySelector("#createSession");
const linksSection = document.querySelector("#sessionLinks");
const carrierInput = document.querySelector("#carrierLink");
const operatorInput = document.querySelector("#operatorLink");
const openCarrier = document.querySelector("#openCarrier");
const openOperator = document.querySelector("#openOperator");
const shareOperator = document.querySelector("#shareOperator");
const webStatus = document.querySelector("#webStatus");
const sessionIdLabel = document.querySelector("#sessionId");
const profileName = document.querySelector("#profileName");
const profileContact = document.querySelector("#profileContact");
const saveProfile = document.querySelector("#saveProfile");
const version = "20260726-8";
const profileKey = "remote-eyes-profile";

try {
  const savedProfile = JSON.parse(localStorage.getItem(profileKey) || "{}");
  profileName.value = savedProfile.name || "";
  profileContact.value = savedProfile.contact || "";
} catch {
  localStorage.removeItem(profileKey);
}

function makeSessionId() {
  if (crypto.randomUUID) return crypto.randomUUID().replaceAll("-", "");
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  return [...bytes].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

function createSession() {
  const sid = makeSessionId();
  const carrierUrl = new URL("/carrier.html", location.origin);
  const operatorUrl = new URL("/operator.html", location.origin);
  carrierUrl.searchParams.set("sid", sid);
  carrierUrl.searchParams.set("v", version);
  operatorUrl.searchParams.set("sid", sid);
  operatorUrl.searchParams.set("v", version);
  if (profileName.value.trim()) {
    operatorUrl.searchParams.set("name", profileName.value.trim().slice(0, 60));
  }
  carrierInput.value = carrierUrl.href;
  operatorInput.value = operatorUrl.href;
  openCarrier.href = carrierUrl.href;
  openOperator.href = operatorUrl.href;
  sessionIdLabel.textContent = `Уникальный номер: ${sid.slice(0, 8)}`;
  linksSection.hidden = false;
  webStatus.textContent = "Созданы две разные ссылки для одной общей сессии.";
}

async function copyInput(id, button) {
  const value = document.querySelector(`#${id}`).value;
  await navigator.clipboard.writeText(value);
  const oldText = button.textContent;
  button.textContent = "Скопировано ✓";
  setTimeout(() => { button.textContent = oldText; }, 1200);
}

createButton.onclick = createSession;
saveProfile.onclick = () => {
  localStorage.setItem(profileKey, JSON.stringify({
    name: profileName.value.trim().slice(0, 60),
    contact: profileContact.value.trim().slice(0, 120),
  }));
  saveProfile.textContent = "Профиль сохранён ✓";
  setTimeout(() => { saveProfile.textContent = "Сохранить профиль"; }, 1400);
};
document.querySelectorAll("[data-copy]").forEach((button) => {
  button.onclick = () => copyInput(button.dataset.copy, button);
});
shareOperator.onclick = async () => {
  const url = operatorInput.value;
  if (navigator.share) {
    await navigator.share({
      title: "Удалённые глаза — режиссёр",
      text: "Откройте ссылку режиссёра",
      url,
    });
  } else {
    await navigator.clipboard.writeText(url);
    shareOperator.textContent = "Ссылка скопирована ✓";
  }
};
