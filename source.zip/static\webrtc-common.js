export const rtcConfig = {
  iceServers: [
    { urls: "stun:stun.l.google.com:19302" },
    { urls: "stun:stun1.l.google.com:19302" },
    {
      urls: [
        "turn:openrelay.metered.ca:80",
        "turn:openrelay.metered.ca:80?transport=tcp",
        "turn:openrelay.metered.ca:443",
        "turns:openrelay.metered.ca:443?transport=tcp",
      ],
      username: "openrelayproject",
      credential: "openrelayproject",
    },
  ],
  iceCandidatePoolSize: 10,
};

export function sessionId() {
  const sid = new URLSearchParams(location.search).get("sid");
  if (!sid || !/^[a-f0-9-]{16,64}$/i.test(sid)) throw new Error("Некорректная сессия");
  return sid;
}

export function signalSocket(role, onMessage) {
  const scheme = location.protocol === "https:" ? "wss" : "ws";
  const socket = new WebSocket(`${scheme}://${location.host}/ws/${sessionId()}?role=${role}`);
  socket.onmessage = (event) => {
    Promise.resolve(onMessage(JSON.parse(event.data))).catch(console.error);
  };
  return socket;
}

export function sendSignal(socket, payload) {
  if (socket.readyState === WebSocket.OPEN) socket.send(JSON.stringify(payload));
}

export function initTelegramTheme() {
  const webApp = window.Telegram?.WebApp;
  const apply = () => {
    const theme = webApp?.themeParams || {};
    const root = document.documentElement.style;
    const values = {
      "--tg-bg": theme.bg_color,
      "--tg-text": theme.text_color,
      "--tg-hint": theme.hint_color,
      "--tg-link": theme.link_color,
      "--tg-button": theme.button_color,
      "--tg-button-text": theme.button_text_color,
      "--tg-secondary-bg": theme.secondary_bg_color,
    };
    Object.entries(values).forEach(([key, value]) => value && root.setProperty(key, value));
    document.documentElement.dataset.theme = webApp?.colorScheme || "dark";
  };
  apply();
  webApp?.onEvent?.("themeChanged", apply);
  webApp?.ready?.();
  webApp?.expand?.();
}

export function trackEvent(name, data = {}) {
  try {
    const key = "teleglaz-events";
    const events = JSON.parse(localStorage.getItem(key) || "[]");
    events.push({ name, data, at: new Date().toISOString() });
    localStorage.setItem(key, JSON.stringify(events.slice(-100)));
  } catch {
    // Метрики не должны мешать основной функции приложения.
  }
}

export async function copyText(value) {
  if (navigator.clipboard?.writeText) {
    try {
      await navigator.clipboard.writeText(value);
      return true;
    } catch {
      // Используем совместимый fallback для встроенных браузеров.
    }
  }
  const field = document.createElement("textarea");
  field.value = value;
  field.style.position = "fixed";
  field.style.opacity = "0";
  document.body.append(field);
  field.select();
  const copied = document.execCommand("copy");
  field.remove();
  return copied;
}
