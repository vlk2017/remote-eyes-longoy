export const rtcConfig = {
  iceServers: [
    { urls: "stun:stun.l.google.com:19302" },
    { urls: "stun:stun1.l.google.com:19302" },
    {
      urls: [
        "turn:openrelay.metered.ca:80",
        "turn:openrelay.metered.ca:80?transport=tcp",
        "turn:openrelay.metered.ca:443",
        "turns:openrelay.metered.ca:443?transport=tcp",
      ],
      username: "openrelayproject",
      credential: "openrelayproject",
    },
  ],
  iceCandidatePoolSize: 10,
};

export function sessionId() {
  const sid = new URLSearchParams(location.search).get("sid");
  if (!sid || !/^[a-f0-9-]{16,64}$/i.test(sid)) throw new Error("Некорректная сессия");
  return sid;
}

export function signalSocket(role, onMessage) {
  const scheme = location.protocol === "https:" ? "wss" : "ws";
  const socket = new WebSocket(`${scheme}://${location.host}/ws/${sessionId()}?role=${role}`);
  socket.onmessage = (event) => {
    Promise.resolve(onMessage(JSON.parse(event.data))).catch(console.error);
  };
  return socket;
}

export function sendSignal(socket, payload) {
  if (socket.readyState === WebSocket.OPEN) socket.send(JSON.stringify(payload));
}
