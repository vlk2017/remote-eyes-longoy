from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field

from fastapi import WebSocket


@dataclass
class Session:
    created_at: float = field(default_factory=time.monotonic)
    peers: dict[str, WebSocket] = field(default_factory=dict)


class SessionStore:
    def __init__(self, ttl_seconds: int = 7200) -> None:
        self.ttl_seconds = ttl_seconds
        self._sessions: dict[str, Session] = {}
        self._lock = asyncio.Lock()

    async def add(self, session_id: str, role: str, websocket: WebSocket) -> WebSocket | None:
        async with self._lock:
            self._cleanup()
            session = self._sessions.setdefault(session_id, Session())
            previous = session.peers.get(role)
            session.peers[role] = websocket
            return previous

    async def remove(self, session_id: str, role: str, websocket: WebSocket) -> None:
        async with self._lock:
            session = self._sessions.get(session_id)
            if not session:
                return
            if session.peers.get(role) is websocket:
                session.peers.pop(role, None)
            if not session.peers:
                self._sessions.pop(session_id, None)

    async def peer(self, session_id: str, role: str) -> WebSocket | None:
        async with self._lock:
            session = self._sessions.get(session_id)
            if not session:
                return None
            other_role = "operator" if role == "carrier" else "carrier"
            return session.peers.get(other_role)

    def _cleanup(self) -> None:
        now = time.monotonic()
        expired = [
            session_id
            for session_id, session in self._sessions.items()
            if now - session.created_at > self.ttl_seconds
        ]
        for session_id in expired:
            self._sessions.pop(session_id, None)


sessions = SessionStore()
