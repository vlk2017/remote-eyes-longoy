from __future__ import annotations

import asyncio
import os
from uuid import uuid4

from aiogram import Bot, Dispatcher, Router
from aiogram.filters import CommandStart
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, Message, WebAppInfo
from dotenv import load_dotenv

router = Router()


@router.message(CommandStart())
async def start(message: Message) -> None:
    base_url = os.environ["WEBAPP_BASE_URL"].rstrip("/")
    session_id = uuid4().hex
    carrier_url = f"{base_url}/carrier.html?sid={session_id}"
    operator_url = f"{base_url}/operator.html?sid={session_id}"
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📷 Я — Носитель", url=carrier_url)],
            [InlineKeyboardButton(text="🧭 Я — Оператор", url=operator_url)],
        ]
    )
    await message.answer(
        "Новая приватная сессия готова.\n\n"
        "Откройте «Я — Носитель» на телефоне с камерой. "
        "Ссылку «Я — Оператор» отправьте собеседнику.\n\n"
        f"Ссылка для оператора:\n{operator_url}\n\n"
        "Видео передаётся напрямую между устройствами и не записывается.",
        reply_markup=keyboard,
    )


def build_dispatcher() -> Dispatcher:
    dispatcher = Dispatcher()
    dispatcher.include_router(router)
    return dispatcher


async def main() -> None:
    load_dotenv()
    bot = Bot(os.environ["BOT_TOKEN"])
    try:
        await build_dispatcher().start_polling(bot)
    finally:
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
