from __future__ import annotations

import asyncio
import os
from uuid import uuid4
from urllib.parse import quote

from aiogram import Bot, Dispatcher, Router
from aiogram.filters import CommandStart
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, Message
from dotenv import load_dotenv

router = Router()
APP_VERSION = "20260726-14"


@router.message(CommandStart())
async def start(message: Message) -> None:
    base_url = os.environ["WEBAPP_BASE_URL"].rstrip("/")
    session_id = uuid4().hex
    carrier_url = f"{base_url}/carrier.html?sid={session_id}&v={APP_VERSION}"
    operator_url = f"{base_url}/operator.html?sid={session_id}&v={APP_VERSION}"
    telegram_share_url = (
        "https://t.me/share/url?url="
        f"{quote(operator_url, safe='')}&text="
        f"{quote('🎬 ТЕЛЕГЛАЗ: подключайся как режиссёр. Ничего скачивать не нужно.', safe='')}"
    )
    carrier_keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📷 Я — оператор", url=carrier_url)],
        ]
    )
    director_keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🎬 Я — режиссёр", url=operator_url)],
            [InlineKeyboardButton(text="✈️ Отправить режиссёру в Telegram", url=telegram_share_url)],
        ]
    )
    await message.answer(
        "👁 ТЕЛЕГЛАЗ — посмотрите чужими глазами в реальном времени. "
        "Один человек показывает, другой направляет взгляд.\n\n"
        "Новая приватная сессия готова. Займёт минуту, ничего скачивать не нужно.\n\n"
        "1. Откройте «Я — оператор» на телефоне с камерой и разрешите камеру.\n"
        "2. Перешлите режиссёру следующее отдельное сообщение.\n"
        "3. Используйте только новые ссылки на remote-eyes-longoy.onrender.com. "
        "Старый адрес soulsok.chatgpt.site больше не используется.\n\n"
        "Видео доступно только участникам сессии. Запись включается режиссёром вручную."
    )
    await message.answer(
        f"📷 ОПЕРАТОР · КАМЕРА\n\nОткройте свою ссылку:\n{carrier_url}",
        reply_markup=carrier_keyboard,
    )
    await message.answer(
        "👁 ПЕРЕШЛИТЕ РЕЖИССЁРУ\n\n"
        "Я хочу показать тебе вид со своего телефона — посмотри и направляй меня стрелками.\n"
        "Займёт минуту, ничего скачивать не нужно.\n\n"
        f"{operator_url}",
        reply_markup=director_keyboard,
    )


def build_dispatcher() -> Dispatcher:
    dispatcher = Dispatcher()
    dispatcher.include_router(router)
    return dispatcher


async def main() -> None:
    load_dotenv()
    bot = Bot(os.environ["BOT_TOKEN"])
    try:
        await build_dispatcher().start_polling(bot)
    finally:
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
