import { rtcConfig, sendSignal, signalSocket } from "./webrtc-common.js";

const video = document.querySelector("#localVideo");
const status = document.querySelector("#status");
const overlay = document.querySelector("#direction");
const startButton = document.querySelector("#startCamera");
const flipButton = document.querySelector("#flipCamera");
const orientationButton = document.querySelector("#orientation");
let stream;
let facingMode = "environment";
let peer;
let socket;
let started = false;

async function startCamera() {
  stream?.getTracks().forEach((track) => track.stop());
  if (!navigator.mediaDevices?.getUserMedia) {
    throw new Error("Откройте ссылку во внешнем Chrome или Safari");
  }
  try {
    stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: { ideal: facingMode }, width: { ideal: 1280 }, height: { ideal: 720 } },
      audio: false,
    });
  } catch {
    stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
  }
  video.srcObject = stream;
  startButton.hidden = true;
  flipButton.disabled = false;
  status.textContent = "Ожидание оператора…";
  connect();
}

function connect() {
  if (socket) return;
  socket = signalSocket("carrier", handleSignal);
  socket.onclose = () => { status.textContent = "Связь прервана"; };
}

async function createOffer() {
  if (!stream || started) return;
  started = true;
  peer = new RTCPeerConnection(rtcConfig);
  stream.getTracks().forEach((track) => peer.addTrack(track, stream));
  peer.onicecandidate = ({ candidate }) => candidate && sendSignal(socket, { type: "ice", candidate });
  peer.onconnectionstatechange = () => {
    status.textContent = peer.connectionState === "connected" ? "Оператор подключён" : `Связь: ${peer.connectionState}`;
  };
  peer.ondatachannel = ({ channel }) => {
    channel.onmessage = ({ data }) => showDirection(JSON.parse(data).direction);
  };
  await peer.setLocalDescription(await peer.createOffer());
  sendSignal(socket, { type: "offer", sdp: peer.localDescription });
}

async function handleSignal(message) {
  if (message.type === "peer-ready") await createOffer();
  if (message.type === "answer" && peer) await peer.setRemoteDescription(message.sdp);
  if (message.type === "ice" && peer) await peer.addIceCandidate(message.candidate);
  if (message.type === "peer-left") status.textContent = "Оператор отключился";
}

function showDirection(direction) {
  const arrows = { up: "▲", right: "▶", down: "▼", left: "◀" };
  overlay.textContent = arrows[direction] || "";
  overlay.className = `direction ${direction || ""}`;
  if (direction !== "stop") navigator.vibrate?.(100);
}

startButton.onclick = () => startCamera().catch((error) => { status.textContent = `Камера недоступна: ${error.message}`; });
flipButton.onclick = async () => { facingMode = facingMode === "user" ? "environment" : "user"; await startCamera(); };
orientationButton.onclick = async () => {
  const OrientationEvent = window.DeviceOrientationEvent;
  if (!OrientationEvent) {
    status.textContent = "Гироскоп недоступен. Откройте ссылку в Chrome или Safari";
    return;
  }
  if (typeof OrientationEvent.requestPermission === "function") {
    const permission = await OrientationEvent.requestPermission();
    if (permission !== "granted") {
      status.textContent = "Разрешите доступ к движению телефона";
      return;
    }
  }
  orientationButton.classList.toggle("active");
  status.textContent = orientationButton.classList.contains("active")
    ? "Стабилизация наклона включена"
    : "Стабилизация наклона выключена";
};

const samples = [];
window.addEventListener("deviceorientation", ({ beta, gamma }) => {
  if (!orientationButton.classList.contains("active") || beta == null || gamma == null) return;
  samples.push({ beta, gamma });
  if (samples.length > 10) samples.shift();
  const avg = samples.reduce((a, v) => ({ beta: a.beta + v.beta, gamma: a.gamma + v.gamma }), { beta: 0, gamma: 0 });
  const dx = Math.max(-8, Math.min(8, (gamma - avg.gamma / samples.length) * -0.3));
  const dy = Math.max(-8, Math.min(8, (beta - avg.beta / samples.length) * -0.3));
  video.style.transform = `scale(1.04) translate(${dx}px, ${dy}px)`;
  // TODO: полноценную стабилизацию можно добавить через canvas-анализ и обрезку кадров.
});

window.Telegram?.WebApp?.expand();
