import { initTelegramTheme, sendSignal, signalSocket, trackEvent } from "./webrtc-common.js";

const video = document.querySelector("#localVideo");
const status = document.querySelector("#status");
const overlay = document.querySelector("#direction");
const startButton = document.querySelector("#startCamera");
const flipButton = document.querySelector("#flipCamera");
const permissionIntro = document.querySelector("#permissionIntro");
const cameraFallback = document.querySelector("#cameraFallback");
const retryButton = document.querySelector("#retryCamera");
const shareDirectorButton = document.querySelector("#shareDirector");
const carrierShareChoices = document.querySelector("#carrierShareChoices");
const carrierTelegram = document.querySelector("#carrierTelegram");
const carrierWhatsApp = document.querySelector("#carrierWhatsApp");
const carrierSms = document.querySelector("#carrierSms");
const carrierOther = document.querySelector("#carrierOther");
const reconnectPanel = document.querySelector("#reconnectPanel");
const reconnectButton = document.querySelector("#reconnectNow");
const sessionEnd = document.querySelector("#sessionEnd");
const durationLabel = document.querySelector("#sessionDuration");
const endButton = document.querySelector("#endSession");
const canvas = document.createElement("canvas");
const context = canvas.getContext("2d", { alpha: false });
let stream;
let facingMode = "environment";
let socket;
let frameTimer;
let reconnectTimer;
let audioStream;
let audioContext;
let audioSource;
let audioProcessor;
let reconnectAttempts = 0;
let sessionEnded = false;
const sessionStartedAt = Date.now();

function setStatus(text, state = "connecting") {
  status.className = `status ${state}`;
  status.replaceChildren(document.createElement("i"), Object.assign(document.createElement("span"), { textContent: text }));
}

async function startCamera() {
  trackEvent("camera_button_clicked");
  clearInterval(frameTimer);
  stream?.getTracks().forEach((track) => track.stop());
  if (!navigator.mediaDevices?.getUserMedia) {
    throw new Error("Откройте ссылку во внешнем Chrome или Safari");
  }
  try {
    stream = await navigator.mediaDevices.getUserMedia({
      video: {
        facingMode: { ideal: facingMode },
        width: { ideal: 1280 },
        height: { ideal: 720 },
      },
      audio: false,
    });
  } catch {
    stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
  }
  video.srcObject = stream;
  await video.play();
  permissionIntro.hidden = true;
  cameraFallback.hidden = true;
  flipButton.disabled = false;
  endButton.disabled = false;
  trackEvent("camera_permission_granted");
  setStatus("Ждём режиссёра…");
  connect();
  startFrameRelay();
}

function connect() {
  if (socket && socket.readyState < WebSocket.CLOSING) return;
  clearTimeout(reconnectTimer);
  socket = signalSocket("carrier", handleSignal);
  socket.onopen = () => {
    reconnectAttempts = 0;
    reconnectPanel.hidden = true;
    setStatus("Ждём режиссёра…");
  };
  socket.onclose = () => {
    if (sessionEnded) return;
    setStatus("Связь прервалась — переподключаемся…", "weak");
    socket = undefined;
    reconnectAttempts += 1;
    if (reconnectAttempts <= 5) {
      reconnectTimer = setTimeout(connect, 3000);
    } else {
      reconnectPanel.hidden = false;
      trackEvent("reconnect_exhausted", { role: "operator_camera" });
    }
  };
}

function startFrameRelay() {
  clearInterval(frameTimer);
  frameTimer = setInterval(() => {
    if (
      socket?.readyState !== WebSocket.OPEN ||
      socket.bufferedAmount > 140000 ||
      video.readyState < HTMLMediaElement.HAVE_CURRENT_DATA
    ) return;
    const sourceWidth = video.videoWidth || 640;
    const sourceHeight = video.videoHeight || 360;
    const width = Math.min(480, sourceWidth);
    const height = Math.round(width * sourceHeight / sourceWidth);
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }
    context.drawImage(video, 0, 0, width, height);
    sendSignal(socket, {
      type: "frame",
      data: canvas.toDataURL("image/jpeg", 0.52),
    });
  }, 125);
}

function handleSignal(message) {
  if (message.type === "peer-ready" || message.type === "operator-ready") {
    setStatus("На связи", "live");
    trackEvent("peer_connected", { role: "operator_camera" });
  }
  if (message.type === "audio-control") setAudioRelay(Boolean(message.enabled));
  if (message.type === "command") {
    showCommand(message.command || "stop", message.source);
  }
  if (message.type === "peer-left") {
    setStatus("Режиссёр отключился", "weak");
    setAudioRelay(false);
    overlay.className = "direction stop";
  }
  if (message.type === "session-end") finishSession();
}

function finishSession(notifyPeer = false) {
  if (sessionEnded) return;
  if (notifyPeer) sendSignal(socket, { type: "session-end" });
  sessionEnded = true;
  clearTimeout(reconnectTimer);
  clearInterval(frameTimer);
  stream?.getTracks().forEach((track) => track.stop());
  setAudioRelay(false);
  const minutes = Math.max(1, Math.round((Date.now() - sessionStartedAt) / 60000));
  durationLabel.textContent = `Сеанс длился ${minutes} мин`;
  sessionEnd.hidden = false;
  setStatus("Сеанс завершён", "live");
  trackEvent("session_ended", { role: "operator_camera", minutes });
}

function encodePcm(floatData, inputRate, outputRate = 12000) {
  const ratio = inputRate / outputRate;
  const length = Math.floor(floatData.length / ratio);
  const bytes = new Uint8Array(length * 2);
  for (let i = 0; i < length; i += 1) {
    const start = Math.floor(i * ratio);
    const end = Math.max(start + 1, Math.floor((i + 1) * ratio));
    let sum = 0;
    for (let j = start; j < end && j < floatData.length; j += 1) sum += floatData[j];
    const value = Math.max(-1, Math.min(1, sum / (end - start)));
    const sample = value < 0 ? value * 32768 : value * 32767;
    bytes[i * 2] = sample & 255;
    bytes[i * 2 + 1] = (sample >> 8) & 255;
  }
  let binary = "";
  for (let i = 0; i < bytes.length; i += 1) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

async function setAudioRelay(enabled) {
  if (!enabled) {
    audioProcessor?.disconnect();
    audioSource?.disconnect();
    audioStream?.getTracks().forEach((track) => track.stop());
    audioContext?.close();
    audioProcessor = audioSource = audioStream = audioContext = undefined;
    return;
  }
  if (audioStream) return;
  try {
    audioStream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
    });
    audioContext = new AudioContext({ latencyHint: "interactive" });
    audioSource = audioContext.createMediaStreamSource(audioStream);
    audioProcessor = audioContext.createScriptProcessor(2048, 1, 1);
    audioProcessor.onaudioprocess = (event) => {
      if (socket?.readyState !== WebSocket.OPEN || socket.bufferedAmount > 90000) return;
      sendSignal(socket, {
        type: "audio",
        sampleRate: 12000,
        data: encodePcm(event.inputBuffer.getChannelData(0), audioContext.sampleRate),
      });
    };
    audioSource.connect(audioProcessor);
    audioProcessor.connect(audioContext.destination);
    setStatus("На связи · звук включён", "live");
  } catch {
    sendSignal(socket, { type: "audio-error", message: "Разрешите микрофон оператору" });
  }
}

function showCommand(command, source = "manual") {
  const commands = {
    move_forward: ["↑", "ИДИ ВПЕРЁД"],
    move_back: ["↓", "ИДИ НАЗАД"],
    move_left: ["⇦", "ШАГ ВЛЕВО"],
    move_right: ["⇨", "ШАГ ВПРАВО"],
    turn_left: ["↶", "ПОВЕРНИ НАЛЕВО"],
    turn_right: ["↷", "ПОВЕРНИ НАПРАВО"],
    tilt_up: ["⤴", "КАМЕРУ ВЫШЕ"],
    tilt_down: ["⤵", "КАМЕРУ НИЖЕ"],
  };
  const item = commands[command];
  if (!item) {
    overlay.replaceChildren();
    overlay.className = "direction stop";
    return;
  }
  const icon = document.createElement("div");
  icon.className = "direction-icon";
  icon.textContent = item[0];
  const label = document.createElement("div");
  label.className = "direction-label";
  label.textContent = item[1];
  overlay.replaceChildren(icon, label);
  overlay.className = `direction ${source === "gyro" ? "turn-command" : "move-command"}`;
  navigator.vibrate?.(source === "gyro" ? 60 : 120);
}

startButton.onclick = () =>
  startCamera().catch((error) => {
    permissionIntro.hidden = true;
    cameraFallback.hidden = false;
    setStatus("Нужно разрешение камеры", "weak");
  });
retryButton.onclick = startButton.onclick;
reconnectButton.onclick = () => {
  reconnectAttempts = 0;
  reconnectPanel.hidden = true;
  connect();
};
endButton.onclick = () => finishSession(true);
shareDirectorButton.onclick = () => {
  const directorUrl = new URL("/operator.html", location.origin);
  directorUrl.searchParams.set("sid", new URLSearchParams(location.search).get("sid"));
  directorUrl.searchParams.set("v", "20260726-11");
  const text = "🎬 ТЕЛЕГЛАЗ: подключайтесь как режиссёр — смотрите видео и направляйте меня.";
  carrierTelegram.href = `https://t.me/share/url?url=${encodeURIComponent(directorUrl.href)}&text=${encodeURIComponent(text)}`;
  carrierWhatsApp.href = `https://wa.me/?text=${encodeURIComponent(`${text}\n${directorUrl.href}`)}`;
  carrierSms.href = `sms:?&body=${encodeURIComponent(`${text}\n${directorUrl.href}`)}`;
  carrierShareChoices.hidden = !carrierShareChoices.hidden;
};
carrierOther.onclick = async () => {
  const directorUrl = new URL("/operator.html", location.origin);
  directorUrl.searchParams.set("sid", new URLSearchParams(location.search).get("sid"));
  directorUrl.searchParams.set("v", "20260726-11");
  if (navigator.share) {
    await navigator.share({ title: "ТЕЛЕГЛАЗ", text: "Подключайтесь как режиссёр", url: directorUrl.href });
  } else {
    await navigator.clipboard.writeText(directorUrl.href);
    carrierOther.textContent = "Скопировано ✓";
  }
};
flipButton.onclick = async () => {
  facingMode = facingMode === "user" ? "environment" : "user";
  await startCamera();
};

initTelegramTheme();
trackEvent("camera_page_opened");
