import { sendSignal, signalSocket } from "./webrtc-common.js";

const video = document.querySelector("#localVideo");
const status = document.querySelector("#status");
const overlay = document.querySelector("#direction");
const startButton = document.querySelector("#startCamera");
const flipButton = document.querySelector("#flipCamera");
const canvas = document.createElement("canvas");
const context = canvas.getContext("2d", { alpha: false });
let stream;
let facingMode = "environment";
let socket;
let frameTimer;
let reconnectTimer;

async function startCamera() {
  clearInterval(frameTimer);
  stream?.getTracks().forEach((track) => track.stop());
  if (!navigator.mediaDevices?.getUserMedia) {
    throw new Error("Откройте ссылку во внешнем Chrome или Safari");
  }
  try {
    stream = await navigator.mediaDevices.getUserMedia({
      video: {
        facingMode: { ideal: facingMode },
        width: { ideal: 1280 },
        height: { ideal: 720 },
      },
      audio: false,
    });
  } catch {
    stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
  }
  video.srcObject = stream;
  await video.play();
  startButton.hidden = true;
  flipButton.disabled = false;
  status.textContent = "Камера включена — ожидание оператора…";
  connect();
  startFrameRelay();
}

function connect() {
  if (socket && socket.readyState < WebSocket.CLOSING) return;
  clearTimeout(reconnectTimer);
  socket = signalSocket("carrier", handleSignal);
  socket.onopen = () => { status.textContent = "Камера включена — ожидание оператора…"; };
  socket.onclose = () => {
    status.textContent = "Сеть изменилась — переподключение…";
    socket = undefined;
    reconnectTimer = setTimeout(connect, 1500);
  };
}

function startFrameRelay() {
  clearInterval(frameTimer);
  frameTimer = setInterval(() => {
    if (
      socket?.readyState !== WebSocket.OPEN ||
      video.readyState < HTMLMediaElement.HAVE_CURRENT_DATA
    ) return;
    const sourceWidth = video.videoWidth || 640;
    const sourceHeight = video.videoHeight || 360;
    const width = Math.min(360, sourceWidth);
    const height = Math.round(width * sourceHeight / sourceWidth);
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }
    context.drawImage(video, 0, 0, width, height);
    sendSignal(socket, {
      type: "frame",
      data: canvas.toDataURL("image/jpeg", 0.45),
    });
  }, 400);
}

function handleSignal(message) {
  if (message.type === "peer-ready" || message.type === "operator-ready") {
    status.textContent = "Оператор подключён";
  }
  if (message.type === "command") {
    showCommand(message.command || "stop", message.source);
  }
  if (message.type === "peer-left") {
    status.textContent = "Оператор отключился";
    overlay.className = "direction stop";
  }
}

function showCommand(command, source = "manual") {
  const commands = {
    move_forward: ["↑", "ИДИ ВПЕРЁД"],
    move_back: ["↓", "ИДИ НАЗАД"],
    move_left: ["⇦", "ШАГ ВЛЕВО"],
    move_right: ["⇨", "ШАГ ВПРАВО"],
    turn_left: ["↶", "ПОВЕРНИ НАЛЕВО"],
    turn_right: ["↷", "ПОВЕРНИ НАПРАВО"],
    tilt_up: ["⤴", "КАМЕРУ ВЫШЕ"],
    tilt_down: ["⤵", "КАМЕРУ НИЖЕ"],
  };
  const item = commands[command];
  if (!item) {
    overlay.replaceChildren();
    overlay.className = "direction stop";
    return;
  }
  const icon = document.createElement("div");
  icon.className = "direction-icon";
  icon.textContent = item[0];
  const label = document.createElement("div");
  label.className = "direction-label";
  label.textContent = item[1];
  overlay.replaceChildren(icon, label);
  overlay.className = `direction ${source === "gyro" ? "turn-command" : "move-command"}`;
  navigator.vibrate?.(source === "gyro" ? 60 : 120);
}

startButton.onclick = () =>
  startCamera().catch((error) => {
    status.textContent = `Камера недоступна: ${error.message}`;
  });
flipButton.onclick = async () => {
  facingMode = facingMode === "user" ? "environment" : "user";
  await startCamera();
};

window.Telegram?.WebApp?.expand();
