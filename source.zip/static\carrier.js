import { rtcConfig, sendSignal, signalSocket } from "./webrtc-common.js";

const video = document.querySelector("#localVideo");
const status = document.querySelector("#status");
const overlay = document.querySelector("#direction");
const startButton = document.querySelector("#startCamera");
const flipButton = document.querySelector("#flipCamera");
let stream;
let facingMode = "environment";
let peer;
let socket;
let started = false;
let pendingIce = [];

async function startCamera() {
  stream?.getTracks().forEach((track) => track.stop());
  if (!navigator.mediaDevices?.getUserMedia) {
    throw new Error("Откройте ссылку во внешнем Chrome или Safari");
  }
  try {
    stream = await navigator.mediaDevices.getUserMedia({
      video: {
        facingMode: { ideal: facingMode },
        width: { ideal: 1280 },
        height: { ideal: 720 },
      },
      audio: false,
    });
  } catch {
    stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
  }
  video.srcObject = stream;
  startButton.hidden = true;
  flipButton.disabled = false;
  status.textContent = "Ожидание оператора…";
  connect();
}

function connect() {
  if (socket && socket.readyState < WebSocket.CLOSING) return;
  socket = signalSocket("carrier", handleSignal);
  socket.onclose = () => {
    status.textContent = "Связь прервана — обновите страницу";
    socket = undefined;
    peer?.close();
    peer = undefined;
    started = false;
  };
}

async function createOffer() {
  if (!stream || started) return;
  started = true;
  peer?.close();
  pendingIce = [];
  peer = new RTCPeerConnection(rtcConfig);
  stream.getTracks().forEach((track) => peer.addTrack(track, stream));
  peer.onicecandidate = ({ candidate }) =>
    candidate && sendSignal(socket, { type: "ice", candidate });
  peer.onconnectionstatechange = () => {
    status.textContent = peer.connectionState === "connected"
      ? "Оператор подключён"
      : `Связь: ${peer.connectionState}`;
    if (peer.connectionState === "failed") {
      started = false;
      peer.close();
      peer = undefined;
    }
  };
  peer.ondatachannel = ({ channel }) => {
    channel.onopen = () => { status.textContent = "Оператор подключён"; };
    channel.onmessage = ({ data }) => {
      const message = JSON.parse(data);
      showCommand(message.command || message.direction || "stop", message.source);
    };
  };
  await peer.setLocalDescription(await peer.createOffer());
  sendSignal(socket, { type: "offer", sdp: peer.localDescription });
}

async function handleSignal(message) {
  if (message.type === "peer-ready") await createOffer();
  if (message.type === "answer" && peer) {
    await peer.setRemoteDescription(message.sdp);
    for (const candidate of pendingIce.splice(0)) await peer.addIceCandidate(candidate);
  }
  if (message.type === "ice" && peer) {
    if (peer.remoteDescription) await peer.addIceCandidate(message.candidate);
    else pendingIce.push(message.candidate);
  }
  if (message.type === "peer-left") {
    status.textContent = "Оператор отключился";
    overlay.className = "direction stop";
    peer?.close();
    peer = undefined;
    started = false;
  }
}

function showCommand(command, source = "manual") {
  const commands = {
    move_forward: ["↑", "ИДИ ВПЕРЁД"],
    move_back: ["↓", "ИДИ НАЗАД"],
    move_left: ["⇦", "ШАГ ВЛЕВО"],
    move_right: ["⇨", "ШАГ ВПРАВО"],
    turn_left: ["↶", "ПОВЕРНИ НАЛЕВО"],
    turn_right: ["↷", "ПОВЕРНИ НАПРАВО"],
    tilt_up: ["⤴", "КАМЕРУ ВЫШЕ"],
    tilt_down: ["⤵", "КАМЕРУ НИЖЕ"],
  };
  const item = commands[command];
  if (!item) {
    overlay.replaceChildren();
    overlay.className = "direction stop";
    return;
  }
  const icon = document.createElement("div");
  icon.className = "direction-icon";
  icon.textContent = item[0];
  const label = document.createElement("div");
  label.className = "direction-label";
  label.textContent = item[1];
  overlay.replaceChildren(icon, label);
  overlay.className = `direction ${source === "gyro" ? "turn-command" : "move-command"}`;
  navigator.vibrate?.(source === "gyro" ? 60 : 120);
}

startButton.onclick = () =>
  startCamera().catch((error) => {
    status.textContent = `Камера недоступна: ${error.message}`;
  });
flipButton.onclick = async () => {
  facingMode = facingMode === "user" ? "environment" : "user";
  await startCamera();
};

window.Telegram?.WebApp?.expand();
