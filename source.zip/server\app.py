from __future__ import annotations

import asyncio
import os
from contextlib import asynccontextmanager, suppress
from pathlib import Path

from aiogram import Bot, Dispatcher
from fastapi import FastAPI, Query, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv

from bot.main import build_dispatcher
from server.sessions import sessions

ROOT = Path(__file__).resolve().parents[1]
STATIC = ROOT / "static"
load_dotenv(ROOT / ".env")


@asynccontextmanager
async def lifespan(_: FastAPI):
    token = os.getenv("BOT_TOKEN")
    task: asyncio.Task | None = None
    bot: Bot | None = None
    if token:
        bot = Bot(token)
        dispatcher: Dispatcher = build_dispatcher()
        task = asyncio.create_task(dispatcher.start_polling(bot))
    yield
    if task:
        task.cancel()
        with suppress(asyncio.CancelledError):
            await task
    if bot:
        await bot.session.close()


app = FastAPI(title="ТЕЛЕГЛАЗ", lifespan=lifespan)
app.mount("/static", StaticFiles(directory=STATIC), name="static")


@app.get("/")
async def index() -> FileResponse:
    return FileResponse(STATIC / "index.html")


@app.get("/{page}.html")
async def page(page: str) -> FileResponse:
    if page not in {"carrier", "operator"}:
        return FileResponse(STATIC / "index.html", status_code=404)
    return FileResponse(STATIC / f"{page}.html")


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@app.websocket("/ws/{session_id}")
async def websocket_endpoint(
    websocket: WebSocket,
    session_id: str,
    role: str = Query(..., pattern="^(carrier|operator)$"),
) -> None:
    await websocket.accept()
    previous = await sessions.add(session_id, role, websocket)
    if previous:
        with suppress(Exception):
            await previous.close(code=4001, reason="Replaced by a new connection")

    peer = await sessions.peer(session_id, role)
    if peer:
        with suppress(Exception):
            await peer.send_json({"type": "peer-ready"})
        await websocket.send_json({"type": "peer-ready"})

    try:
        while True:
            message = await websocket.receive_json()
            peer = await sessions.peer(session_id, role)
            if peer:
                await peer.send_json(message)
    except (WebSocketDisconnect, RuntimeError):
        pass
    finally:
        await sessions.remove(session_id, role, websocket)
        peer = await sessions.peer(session_id, role)
        if peer:
            with suppress(Exception):
                await peer.send_json({"type": "peer-left"})
