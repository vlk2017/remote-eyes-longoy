import { rtcConfig, sendSignal, signalSocket } from "./webrtc-common.js";

const video = document.querySelector("#remoteVideo");
const status = document.querySelector("#status");
const tiltButton = document.querySelector("#tiltMode");
const socket = signalSocket("operator", handleSignal);
let peer;
let channel;
let repeatTimer;
let tiltEnabled = false;
let lastTiltDirection = "stop";
let neutralBeta = null;
let neutralGamma = null;
let pendingIce = [];

async function handleSignal(message) {
  if (message.type === "offer") {
    peer?.close();
    peer = new RTCPeerConnection(rtcConfig);
    pendingIce = [];
    channel = peer.createDataChannel("directions");
    channel.onopen = () => { status.textContent = "Подключено"; };
    channel.onclose = () => { status.textContent = "Канал управления закрыт"; };
    peer.ontrack = ({ streams }) => {
      video.srcObject = streams[0];
      video.play().catch(() => {});
    };
    peer.onicecandidate = ({ candidate }) =>
      candidate && sendSignal(socket, { type: "ice", candidate });
    peer.onconnectionstatechange = () => {
      status.textContent =
        peer.connectionState === "connected"
          ? "Подключено"
          : `Связь: ${peer.connectionState}`;
    };
    await peer.setRemoteDescription(message.sdp);
    for (const candidate of pendingIce.splice(0)) {
      await peer.addIceCandidate(candidate);
    }
    await peer.setLocalDescription(await peer.createAnswer());
    sendSignal(socket, { type: "answer", sdp: peer.localDescription });
  }
  if (message.type === "ice" && peer) {
    if (peer.remoteDescription) await peer.addIceCandidate(message.candidate);
    else pendingIce.push(message.candidate);
  }
  if (message.type === "peer-left") status.textContent = "Носитель отключился";
}

function sendDirection(direction) {
  if (channel?.readyState === "open") {
    channel.send(JSON.stringify({ direction }));
  }
}

function stop() {
  clearInterval(repeatTimer);
  repeatTimer = undefined;
  sendDirection("stop");
}

document.querySelectorAll(".arrow").forEach((button) => {
  const begin = (event) => {
    event.preventDefault();
    stop();
    const direction = button.dataset.direction;
    sendDirection(direction);
    repeatTimer = setInterval(() => sendDirection(direction), 150);
  };
  button.addEventListener("pointerdown", begin);
  button.addEventListener("pointerup", stop);
  button.addEventListener("pointercancel", stop);
  button.addEventListener("pointerleave", stop);
});

window.addEventListener("pointerup", stop);

tiltButton.onclick = async () => {
  const OrientationEvent = window.DeviceOrientationEvent;
  if (!OrientationEvent) {
    status.textContent = "Гироскоп недоступен. Откройте ссылку в Chrome или Safari";
    return;
  }
  if (typeof OrientationEvent.requestPermission === "function") {
    const permission = await OrientationEvent.requestPermission();
    if (permission !== "granted") {
      status.textContent = "Разрешите доступ к движению телефона";
      return;
    }
  }

  tiltEnabled = !tiltEnabled;
  neutralBeta = null;
  neutralGamma = null;
  lastTiltDirection = "stop";
  tiltButton.classList.toggle("active", tiltEnabled);
  tiltButton.textContent = tiltEnabled
    ? "📱 Наклон включён"
    : "📱 Управлять наклоном";
  status.textContent = tiltEnabled
    ? "Держите телефон ровно, затем наклоняйте"
    : "Управление наклоном выключено";
  sendDirection("stop");
};

window.addEventListener("deviceorientation", ({ beta, gamma }) => {
  if (!tiltEnabled || beta == null || gamma == null) return;
  if (neutralBeta == null || neutralGamma == null) {
    neutralBeta = beta;
    neutralGamma = gamma;
    return;
  }

  const deltaBeta = beta - neutralBeta;
  const deltaGamma = gamma - neutralGamma;
  const angle = screen.orientation?.angle ?? window.orientation ?? 0;
  let vertical = deltaBeta;
  let horizontal = deltaGamma;
  if (Math.abs(angle) === 90) {
    horizontal = angle === 90 ? deltaBeta : -deltaBeta;
    vertical = angle === 90 ? -deltaGamma : deltaGamma;
  }

  const deadZone = 10;
  let direction = "stop";
  if (
    Math.abs(horizontal) > Math.abs(vertical) &&
    Math.abs(horizontal) > deadZone
  ) {
    direction = horizontal > 0 ? "right" : "left";
  } else if (Math.abs(vertical) > deadZone) {
    direction = vertical > 0 ? "down" : "up";
  }

  if (direction !== lastTiltDirection) {
    lastTiltDirection = direction;
    sendDirection(direction);
  }
});

window.Telegram?.WebApp?.expand();
