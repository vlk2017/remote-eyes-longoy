import { sendSignal, signalSocket } from "./webrtc-common.js";

const image = document.querySelector("#remoteImage");
const status = document.querySelector("#status");
const tiltButton = document.querySelector("#tiltMode");
const soundButton = document.querySelector("#soundMode");
const recordButton = document.querySelector("#recordMode");
const recordCanvas = document.createElement("canvas");
const recordContext = recordCanvas.getContext("2d", { alpha: false });
let socket;
let reconnectTimer;
let repeatTimer;
let manualClearTimer;
let orientationWatchdog;
let gyroRepeatTimer;
let orientationSeen = false;
let manualCommand = null;
let tiltEnabled = false;
let neutralBeta = null;
let neutralGamma = null;
let lastTurnCommand = "stop";
let firstFrameSeen = false;
let soundEnabled = false;
let audioContext;
let nextAudioTime = 0;
let mediaRecorder;
let recordChunks = [];
let recordAnimation;
let recordAudioDestination;

function connect() {
  clearTimeout(reconnectTimer);
  socket = signalSocket("operator", handleSignal);
  socket.onopen = () => { status.textContent = "Ожидание оператора…"; };
  socket.onclose = () => {
    status.textContent = "Сеть изменилась — переподключение…";
    firstFrameSeen = false;
    reconnectTimer = setTimeout(connect, 1500);
  };
}

connect();

function handleSignal(message) {
  if (message.type === "peer-ready") {
    status.textContent = firstFrameSeen ? "Подключено — управление готово" : "Оператор подключён, ждём камеру…";
    sendSignal(socket, { type: "operator-ready" });
    if (soundEnabled) sendSignal(socket, { type: "audio-control", enabled: true });
  }
  if (message.type === "frame" && message.data) {
    image.src = message.data;
    if (!firstFrameSeen) {
      firstFrameSeen = true;
      status.textContent = "Подключено — управление готово";
    }
  }
  if (message.type === "audio" && soundEnabled && message.data) {
    playAudioPacket(message.data, message.sampleRate || 12000);
  }
  if (message.type === "audio-error") {
    soundEnabled = false;
    soundButton.textContent = "🔇 Включить звук";
    soundButton.classList.remove("active");
    status.textContent = message.message || "Оператор не разрешил микрофон";
  }
  if (message.type === "peer-left") {
    status.textContent = "Оператор отключился";
    firstFrameSeen = false;
    image.removeAttribute("src");
  }
}

function decodePcm(encoded) {
  const binary = atob(encoded);
  const pcm = new Int16Array(binary.length / 2);
  for (let i = 0; i < pcm.length; i += 1) {
    pcm[i] = binary.charCodeAt(i * 2) | (binary.charCodeAt(i * 2 + 1) << 8);
  }
  return pcm;
}

function playAudioPacket(encoded, sampleRate) {
  if (!audioContext) return;
  const pcm = decodePcm(encoded);
  const buffer = audioContext.createBuffer(1, pcm.length, sampleRate);
  const output = buffer.getChannelData(0);
  for (let i = 0; i < pcm.length; i += 1) output[i] = pcm[i] / 32768;
  const source = audioContext.createBufferSource();
  source.buffer = buffer;
  source.connect(audioContext.destination);
  if (recordAudioDestination) source.connect(recordAudioDestination);
  const now = audioContext.currentTime;
  if (nextAudioTime < now || nextAudioTime > now + 0.7) nextAudioTime = now + 0.06;
  source.start(nextAudioTime);
  nextAudioTime += buffer.duration;
}

soundButton.onclick = async () => {
  soundEnabled = !soundEnabled;
  if (soundEnabled) {
    audioContext ||= new AudioContext({ latencyHint: "interactive", sampleRate: 12000 });
    await audioContext.resume();
    nextAudioTime = audioContext.currentTime;
  }
  sendSignal(socket, { type: "audio-control", enabled: soundEnabled });
  soundButton.classList.toggle("active", soundEnabled);
  soundButton.textContent = soundEnabled ? "🔊 Выключить звук" : "🔇 Включить звук";
};

function drawRecordingFrame() {
  if (image.naturalWidth) {
    const width = image.naturalWidth;
    const height = image.naturalHeight;
    if (recordCanvas.width !== width || recordCanvas.height !== height) {
      recordCanvas.width = width;
      recordCanvas.height = height;
    }
    recordContext.drawImage(image, 0, 0, width, height);
  }
  recordAnimation = requestAnimationFrame(drawRecordingFrame);
}

function stopRecording() {
  if (mediaRecorder?.state === "recording") mediaRecorder.stop();
  cancelAnimationFrame(recordAnimation);
  recordAudioDestination = undefined;
  recordButton.classList.remove("active");
  recordButton.textContent = "⏺ Начать запись";
}

recordButton.onclick = async () => {
  if (mediaRecorder?.state === "recording") {
    stopRecording();
    return;
  }
  if (!image.naturalWidth) {
    status.textContent = "Сначала дождитесь изображения оператора";
    return;
  }
  audioContext ||= new AudioContext({ latencyHint: "interactive", sampleRate: 12000 });
  await audioContext.resume();
  recordAudioDestination = audioContext.createMediaStreamDestination();
  drawRecordingFrame();
  const videoTrack = recordCanvas.captureStream(15).getVideoTracks()[0];
  const tracks = [videoTrack];
  if (soundEnabled) tracks.push(...recordAudioDestination.stream.getAudioTracks());
  const recordingStream = new MediaStream(tracks);
  const mimeType = MediaRecorder.isTypeSupported("video/webm;codecs=vp8,opus")
    ? "video/webm;codecs=vp8,opus"
    : "video/webm";
  recordChunks = [];
  mediaRecorder = new MediaRecorder(recordingStream, {
    mimeType,
    videoBitsPerSecond: 1200000,
    audioBitsPerSecond: 64000,
  });
  mediaRecorder.ondataavailable = (event) => {
    if (event.data.size) recordChunks.push(event.data);
  };
  mediaRecorder.onstop = () => {
    recordingStream.getTracks().forEach((track) => track.stop());
    const blob = new Blob(recordChunks, { type: mimeType });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `remote-eyes-${new Date().toISOString().replaceAll(":", "-")}.webm`;
    link.click();
    setTimeout(() => URL.revokeObjectURL(link.href), 10000);
    status.textContent = "Запись сохранена на устройство режиссёра";
  };
  mediaRecorder.start(1000);
  recordButton.classList.add("active");
  recordButton.textContent = "⏹ Завершить запись";
};

function sendCommand(command, source = "manual") {
  if (socket?.readyState !== WebSocket.OPEN) {
    status.textContent = "Переподключение к серверу…";
    return;
  }
  sendSignal(socket, { type: "command", command, source });
}

function stopManual() {
  clearInterval(repeatTimer);
  repeatTimer = undefined;
  clearTimeout(manualClearTimer);
  manualCommand = null;
  manualClearTimer = setTimeout(() => {
    sendCommand(tiltEnabled ? lastTurnCommand : "stop", tiltEnabled ? "gyro" : "manual");
  }, 1400);
}

document.querySelectorAll(".move").forEach((button) => {
  const begin = (event) => {
    event.preventDefault();
    clearInterval(repeatTimer);
    clearTimeout(manualClearTimer);
    manualCommand = button.dataset.command;
    sendCommand(manualCommand, "manual");
    repeatTimer = setInterval(() => sendCommand(manualCommand, "manual"), 350);
  };
  button.addEventListener("pointerdown", begin);
  button.addEventListener("pointerup", stopManual);
  button.addEventListener("pointercancel", stopManual);
  button.addEventListener("pointerleave", stopManual);
});
window.addEventListener("pointerup", () => manualCommand && stopManual());

tiltButton.onclick = async () => {
  const OrientationEvent = window.DeviceOrientationEvent;
  if (!OrientationEvent) {
    status.textContent = "Гироскоп недоступен. Откройте ссылку в Chrome или Safari";
    return;
  }
  if (typeof OrientationEvent.requestPermission === "function") {
    const permission = await OrientationEvent.requestPermission();
    if (permission !== "granted") {
      status.textContent = "Разрешите доступ к движению телефона";
      return;
    }
  }
  const MotionEvent = window.DeviceMotionEvent;
  if (typeof MotionEvent?.requestPermission === "function") {
    await MotionEvent.requestPermission();
  }
  tiltEnabled = !tiltEnabled;
  clearTimeout(orientationWatchdog);
  clearInterval(gyroRepeatTimer);
  orientationSeen = false;
  neutralBeta = null;
  neutralGamma = null;
  lastTurnCommand = "stop";
  tiltButton.classList.toggle("active", tiltEnabled);
  tiltButton.textContent = tiltEnabled ? "📱 Гироскоп включён" : "📱 Включить гироскоп";
  status.textContent = tiltEnabled
    ? "Держите телефон ровно 1 секунду, затем поворачивайте"
    : "Повороты гироскопом выключены";
  if (tiltEnabled) {
    gyroRepeatTimer = setInterval(() => {
      if (!manualCommand && orientationSeen) sendCommand(lastTurnCommand, "gyro");
    }, 300);
    orientationWatchdog = setTimeout(() => {
      if (!orientationSeen) {
        status.textContent = "Датчик не отвечает — откройте ссылку во внешнем Chrome или Safari";
        tiltEnabled = false;
        tiltButton.classList.remove("active");
        tiltButton.textContent = "📱 Включить гироскоп";
        clearInterval(gyroRepeatTimer);
      }
    }, 3000);
  }
  if (!manualCommand) sendCommand("stop", "gyro");
};

function handleOrientation({ beta, gamma }) {
  if (!tiltEnabled || beta == null || gamma == null) return;
  orientationSeen = true;
  clearTimeout(orientationWatchdog);
  if (neutralBeta == null || neutralGamma == null) {
    neutralBeta = beta;
    neutralGamma = gamma;
    return;
  }
  const deltaBeta = beta - neutralBeta;
  const deltaGamma = gamma - neutralGamma;
  const angle = screen.orientation?.angle ?? window.orientation ?? 0;
  let vertical = deltaBeta;
  let horizontal = deltaGamma;
  if (Math.abs(angle) === 90) {
    horizontal = angle === 90 ? deltaBeta : -deltaBeta;
    vertical = angle === 90 ? -deltaGamma : deltaGamma;
  }
  const deadZone = 9;
  let command = "stop";
  if (Math.abs(horizontal) > Math.abs(vertical) && Math.abs(horizontal) > deadZone) {
    command = horizontal > 0 ? "turn_right" : "turn_left";
  } else if (Math.abs(vertical) > deadZone) {
    command = vertical > 0 ? "tilt_down" : "tilt_up";
  }
  if (command !== lastTurnCommand) {
    lastTurnCommand = command;
    if (!manualCommand) sendCommand(command, "gyro");
  }
}

window.addEventListener("deviceorientation", handleOrientation, true);
window.addEventListener("deviceorientationabsolute", handleOrientation, true);

window.Telegram?.WebApp?.expand();
