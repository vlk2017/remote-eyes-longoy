import { copyText, initTelegramTheme, sendSignal, signalSocket, trackEvent } from "./webrtc-common.js";

const image = document.querySelector("#remoteImage");
const status = document.querySelector("#status");
const tiltButton = document.querySelector("#tiltMode");
const calibrateButton = document.querySelector("#calibrateMode");
const soundButton = document.querySelector("#soundMode");
const recordButton = document.querySelector("#recordMode");
const recordCanvas = document.createElement("canvas");
const recordContext = recordCanvas.getContext("2d", { alpha: false });
const waitingCard = document.querySelector("#waitingCard");
const controlHint = document.querySelector("#controlHint");
const movementPad = document.querySelector(".movement-pad");
const reconnectPanel = document.querySelector("#reconnectPanel");
const reconnectButton = document.querySelector("#reconnectNow");
const sessionEnd = document.querySelector("#sessionEnd");
const durationLabel = document.querySelector("#sessionDuration");
const endButton = document.querySelector("#endSession");
const inviteAgain = document.querySelector("#inviteAgain");
const copyLiveLink = document.querySelector("#copyLiveLink");
const mediaControls = [soundButton, recordButton, tiltButton, calibrateButton];
let socket;
let reconnectTimer;
let repeatTimer;
let manualClearTimer;
let orientationWatchdog;
let gyroRepeatTimer;
let orientationSeen = false;
let manualCommand = null;
let tiltEnabled = false;
let neutralBeta = null;
let neutralGamma = null;
let neutralAlpha = null;
let lastTurnCommand = "stop";
let firstFrameSeen = false;
let soundEnabled = false;
let audioContext;
let nextAudioTime = 0;
let mediaRecorder;
let recordChunks = [];
let recordAnimation;
let recordAudioDestination;
let reconnectAttempts = 0;
let sessionEnded = false;
let lastStabilizerSentAt = 0;
let lastOrientationHandledAt = 0;
let calibrationUntil = 0;
let calibrationSamples = [];
let lastFrameAt = 0;
let connectionHealthTimer;
const sessionStartedAt = Date.now();

function setStatus(text, state = "connecting") {
  status.className = `status ${state}`;
  status.replaceChildren(document.createElement("i"), Object.assign(document.createElement("span"), { textContent: text }));
}

function connect() {
  if (socket && socket.readyState < WebSocket.CLOSING) return;
  clearTimeout(reconnectTimer);
  socket = signalSocket("operator", handleSignal);
  socket.onopen = () => {
    reconnectAttempts = 0;
    reconnectPanel.hidden = true;
    setStatus("Ждём камеру оператора…");
  };
  socket.onclose = () => {
    if (sessionEnded) return;
    setStatus("Связь прервалась — переподключаемся…", "weak");
    firstFrameSeen = false;
    socket = undefined;
    mediaControls.forEach((button) => { button.disabled = true; });
    reconnectAttempts += 1;
    if (reconnectAttempts <= 5) {
      reconnectTimer = setTimeout(connect, 3000);
    } else {
      reconnectPanel.hidden = false;
      trackEvent("reconnect_exhausted", { role: "director" });
    }
  };
}

connect();
connectionHealthTimer = setInterval(() => {
  if (!firstFrameSeen || sessionEnded) return;
  const age = Date.now() - lastFrameAt;
  if (age > 1800) setStatus("Слабый сигнал · ждём новый кадр", "weak");
}, 1000);

function handleSignal(message) {
  if (message.type === "peer-ready") {
    setStatus(firstFrameSeen ? "На связи" : "Оператор подключён · ждём видео", firstFrameSeen ? "live" : "connecting");
    sendSignal(socket, { type: "operator-ready" });
    if (soundEnabled) sendSignal(socket, { type: "audio-control", enabled: true });
  }
  if (message.type === "frame" && message.data) {
    lastFrameAt = Date.now();
    image.src = message.data;
    if (firstFrameSeen && status.classList.contains("weak")) setStatus("На связи", "live");
    if (!firstFrameSeen) {
      firstFrameSeen = true;
      setStatus("На связи", "live");
      waitingCard.hidden = true;
      movementPad.classList.remove("controls-locked");
      mediaControls.forEach((button) => { button.disabled = false; });
      trackEvent("video_received");
      controlHint.hidden = false;
      movementPad.classList.add("controls-intro");
      setTimeout(() => {
        controlHint.hidden = true;
        movementPad.classList.remove("controls-intro");
      }, 3200);
    }
  }
  if (message.type === "audio" && soundEnabled && message.data) {
    playAudioPacket(message.data, message.sampleRate || 12000);
  }
  if (message.type === "audio-error") {
    soundEnabled = false;
    soundButton.textContent = "🔇 Включить звук";
    soundButton.classList.remove("active");
    setStatus(message.message || "Оператор не разрешил микрофон", "weak");
  }
  if (message.type === "peer-left") {
    setStatus("Оператор отключился", "weak");
    waitingCard.hidden = false;
    movementPad.classList.add("controls-locked");
    mediaControls.forEach((button) => { button.disabled = true; });
    firstFrameSeen = false;
    image.removeAttribute("src");
  }
  if (message.type === "session-end") finishSession();
}

function finishSession(notifyPeer = false) {
  if (sessionEnded) return;
  if (notifyPeer) sendSignal(socket, { type: "session-end" });
  sessionEnded = true;
  clearTimeout(reconnectTimer);
  clearInterval(repeatTimer);
  clearInterval(gyroRepeatTimer);
  clearInterval(connectionHealthTimer);
  if (mediaRecorder?.state === "recording") stopRecording();
  const minutes = Math.max(1, Math.round((Date.now() - sessionStartedAt) / 60000));
  durationLabel.textContent = `Сеанс длился ${minutes} мин`;
  sessionEnd.hidden = false;
  movementPad.classList.add("controls-locked");
  setStatus("Сеанс завершён", "live");
  trackEvent("session_ended", { role: "director", minutes });
}

function decodePcm(encoded) {
  const binary = atob(encoded);
  const pcm = new Int16Array(binary.length / 2);
  for (let i = 0; i < pcm.length; i += 1) {
    pcm[i] = binary.charCodeAt(i * 2) | (binary.charCodeAt(i * 2 + 1) << 8);
  }
  return pcm;
}

function playAudioPacket(encoded, sampleRate) {
  if (!audioContext) return;
  const pcm = decodePcm(encoded);
  const buffer = audioContext.createBuffer(1, pcm.length, sampleRate);
  const output = buffer.getChannelData(0);
  for (let i = 0; i < pcm.length; i += 1) output[i] = pcm[i] / 32768;
  const source = audioContext.createBufferSource();
  source.buffer = buffer;
  source.connect(audioContext.destination);
  if (recordAudioDestination) source.connect(recordAudioDestination);
  const now = audioContext.currentTime;
  if (nextAudioTime < now || nextAudioTime > now + 0.7) nextAudioTime = now + 0.06;
  source.start(nextAudioTime);
  nextAudioTime += buffer.duration;
}

soundButton.onclick = async () => {
  soundEnabled = !soundEnabled;
  if (soundEnabled) {
    audioContext ||= new AudioContext({ latencyHint: "interactive", sampleRate: 12000 });
    await audioContext.resume();
    nextAudioTime = audioContext.currentTime;
  }
  sendSignal(socket, { type: "audio-control", enabled: soundEnabled });
  soundButton.classList.toggle("active", soundEnabled);
  soundButton.textContent = soundEnabled ? "🔊 Выключить звук" : "🔇 Включить звук";
};

function drawRecordingFrame() {
  if (image.naturalWidth) {
    const width = image.naturalWidth;
    const height = image.naturalHeight;
    if (recordCanvas.width !== width || recordCanvas.height !== height) {
      recordCanvas.width = width;
      recordCanvas.height = height;
    }
    recordContext.drawImage(image, 0, 0, width, height);
  }
  recordAnimation = requestAnimationFrame(drawRecordingFrame);
}

function stopRecording() {
  if (mediaRecorder?.state === "recording") mediaRecorder.stop();
  cancelAnimationFrame(recordAnimation);
  recordAudioDestination = undefined;
  recordButton.classList.remove("active");
  recordButton.textContent = "⏺ Начать запись";
}

recordButton.onclick = async () => {
  if (mediaRecorder?.state === "recording") {
    stopRecording();
    return;
  }
  if (!image.naturalWidth) {
    setStatus("Сначала дождитесь изображения оператора", "weak");
    return;
  }
  if (!window.MediaRecorder || !recordCanvas.captureStream) {
    setStatus("Запись не поддерживается этим браузером", "weak");
    return;
  }
  audioContext ||= new AudioContext({ latencyHint: "interactive", sampleRate: 12000 });
  await audioContext.resume();
  recordAudioDestination = audioContext.createMediaStreamDestination();
  drawRecordingFrame();
  const videoTrack = recordCanvas.captureStream(15).getVideoTracks()[0];
  const tracks = [videoTrack];
  if (soundEnabled) tracks.push(...recordAudioDestination.stream.getAudioTracks());
  const recordingStream = new MediaStream(tracks);
  const mimeType = MediaRecorder.isTypeSupported("video/webm;codecs=vp8,opus")
    ? "video/webm;codecs=vp8,opus"
    : "video/webm";
  recordChunks = [];
  mediaRecorder = new MediaRecorder(recordingStream, {
    mimeType,
    videoBitsPerSecond: 1200000,
    audioBitsPerSecond: 64000,
  });
  mediaRecorder.ondataavailable = (event) => {
    if (event.data.size) recordChunks.push(event.data);
  };
  mediaRecorder.onstop = () => {
    recordingStream.getTracks().forEach((track) => track.stop());
    const blob = new Blob(recordChunks, { type: mimeType });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `teleglaz-${new Date().toISOString().replaceAll(":", "-")}.webm`;
    link.click();
    setTimeout(() => URL.revokeObjectURL(link.href), 10000);
    setStatus("Запись сохранена на устройство режиссёра", "live");
  };
  mediaRecorder.start(1000);
  recordButton.classList.add("active");
  recordButton.textContent = "⏹ Завершить запись";
};

function sendCommand(command, source = "manual") {
  if (!firstFrameSeen && command !== "stop") {
    setStatus("Сначала дождитесь видео оператора", "connecting");
    return;
  }
  if (socket?.readyState !== WebSocket.OPEN) {
    setStatus("Переподключение к серверу…");
    return;
  }
  sendSignal(socket, { type: "command", command, source });
  if (command !== "stop") trackEvent("command_sent", { command, source });
}

function stopManual() {
  clearInterval(repeatTimer);
  repeatTimer = undefined;
  clearTimeout(manualClearTimer);
  manualCommand = null;
  sendCommand(tiltEnabled ? lastTurnCommand : "stop", tiltEnabled ? "gyro" : "manual");
}

document.querySelectorAll(".move").forEach((button) => {
  const begin = (event) => {
    event.preventDefault();
    clearInterval(repeatTimer);
    clearTimeout(manualClearTimer);
    manualCommand = button.dataset.command;
    sendCommand(manualCommand, "manual");
    repeatTimer = setInterval(() => sendCommand(manualCommand, "manual"), 350);
  };
  button.addEventListener("pointerdown", begin);
  button.addEventListener("pointerup", stopManual);
  button.addEventListener("pointercancel", stopManual);
  button.addEventListener("pointerleave", stopManual);
});
window.addEventListener("pointerup", () => manualCommand && stopManual());

tiltButton.onclick = async () => {
  const OrientationEvent = window.DeviceOrientationEvent;
  if (!OrientationEvent) {
    setStatus("Гироскоп недоступен · откройте ссылку в Chrome или Safari", "weak");
    return;
  }
  if (typeof OrientationEvent.requestPermission === "function") {
    const permission = await OrientationEvent.requestPermission();
    if (permission !== "granted") {
      setStatus("Разрешите доступ к движению телефона", "weak");
      return;
    }
  }
  const MotionEvent = window.DeviceMotionEvent;
  if (typeof MotionEvent?.requestPermission === "function") {
    await MotionEvent.requestPermission();
  }
  tiltEnabled = !tiltEnabled;
  clearTimeout(orientationWatchdog);
  clearInterval(gyroRepeatTimer);
  orientationSeen = false;
  neutralBeta = null;
  neutralGamma = null;
  neutralAlpha = null;
  calibrationSamples = [];
  calibrationUntil = tiltEnabled ? Date.now() + 800 : 0;
  lastTurnCommand = "stop";
  tiltButton.classList.toggle("active", tiltEnabled);
  tiltButton.textContent = tiltEnabled ? "📱 Гироскоп включён" : "📱 Включить гироскоп";
  setStatus(
    tiltEnabled ? "Калибровка: держите телефон ровно одну секунду" : "Повороты гироскопом выключены",
    tiltEnabled ? "connecting" : "live",
  );
  if (tiltEnabled) {
    sendSignal(socket, { type: "stabilize-control", enabled: true });
    gyroRepeatTimer = setInterval(() => {
      if (!manualCommand && orientationSeen) sendCommand(lastTurnCommand, "gyro");
    }, 120);
    orientationWatchdog = setTimeout(() => {
      if (!orientationSeen) {
        setStatus("Датчик не отвечает · откройте ссылку во внешнем Chrome или Safari", "weak");
        tiltEnabled = false;
        sendSignal(socket, { type: "stabilize-control", enabled: false });
        tiltButton.classList.remove("active");
        tiltButton.textContent = "📱 Включить гироскоп";
        clearInterval(gyroRepeatTimer);
      }
    }, 3000);
  }
  if (!tiltEnabled) sendSignal(socket, { type: "stabilize-control", enabled: false });
  if (!manualCommand) sendCommand("stop", "gyro");
};

function angleDelta(value, neutral) {
  if (value == null || neutral == null) return 0;
  return ((value - neutral + 540) % 360) - 180;
}

function handleOrientation({ alpha, beta, gamma }) {
  if (!tiltEnabled || beta == null || gamma == null) return;
  const eventTime = Date.now();
  if (eventTime - lastOrientationHandledAt < 25) return;
  lastOrientationHandledAt = eventTime;
  orientationSeen = true;
  clearTimeout(orientationWatchdog);
  if (eventTime < calibrationUntil) {
    calibrationSamples.push({ alpha, beta, gamma });
    return;
  }
  if (neutralBeta == null || neutralGamma == null) {
    const samples = calibrationSamples.length ? calibrationSamples : [{ alpha, beta, gamma }];
    neutralBeta = samples.reduce((sum, item) => sum + item.beta, 0) / samples.length;
    neutralGamma = samples.reduce((sum, item) => sum + item.gamma, 0) / samples.length;
    neutralAlpha = samples.reduce((sum, item) => sum + (item.alpha ?? 0), 0) / samples.length;
    calibrationSamples = [];
    setStatus("Калибровка готова · поворачивайте телефон", "live");
    return;
  }
  const deltaBeta = beta - neutralBeta;
  const deltaGamma = gamma - neutralGamma;
  const angle = screen.orientation?.angle ?? window.orientation ?? 0;
  let vertical = deltaBeta;
  let horizontal = deltaGamma;
  if (Math.abs(angle) === 90) {
    horizontal = angle === 90 ? deltaBeta : -deltaBeta;
    vertical = angle === 90 ? -deltaGamma : deltaGamma;
  }
  const rotation = angleDelta(alpha, neutralAlpha);
  const now = Date.now();
  if (now - lastStabilizerSentAt >= 60) {
    lastStabilizerSentAt = now;
    sendSignal(socket, {
      type: "stabilize",
      x: Math.max(-30, Math.min(30, horizontal)),
      y: Math.max(-30, Math.min(30, vertical)),
      rotation: Math.max(-45, Math.min(45, rotation)),
      aligned: Math.abs(horizontal) <= 5 && Math.abs(vertical) <= 5 && Math.abs(rotation) <= 7,
    });
  }
  const deadZone = 6;
  let command = "stop";
  if (Math.abs(horizontal) > Math.abs(vertical) && Math.abs(horizontal) > deadZone) {
    command = horizontal > 0 ? "turn_right" : "turn_left";
  } else if (Math.abs(vertical) > deadZone) {
    command = vertical > 0 ? "tilt_up" : "tilt_down";
  }
  if (command !== lastTurnCommand) {
    lastTurnCommand = command;
    if (!manualCommand) sendCommand(command, "gyro");
  }
}

window.addEventListener("deviceorientation", handleOrientation, true);
window.addEventListener("deviceorientationabsolute", handleOrientation, true);

reconnectButton.onclick = () => {
  reconnectAttempts = 0;
  reconnectPanel.hidden = true;
  connect();
};
calibrateButton.onclick = () => {
  if (!tiltEnabled) {
    setStatus("Сначала включите гироскоп", "weak");
    return;
  }
  neutralBeta = neutralGamma = neutralAlpha = null;
  calibrationSamples = [];
  calibrationUntil = Date.now() + 800;
  lastTurnCommand = "stop";
  sendCommand("stop", "gyro");
  setStatus("Держите телефон ровно одну секунду", "connecting");
  trackEvent("gyro_recalibrated");
};
endButton.onclick = () => finishSession(true);
inviteAgain.onclick = () => { location.href = "/"; };
copyLiveLink.onclick = async () => {
  await copyText(location.href);
  const oldText = copyLiveLink.textContent;
  copyLiveLink.textContent = "Ссылка скопирована ✓";
  setTimeout(() => { copyLiveLink.textContent = oldText; }, 1400);
  trackEvent("live_link_copied", { role: "director" });
};

initTelegramTheme();
trackEvent("director_page_opened");
