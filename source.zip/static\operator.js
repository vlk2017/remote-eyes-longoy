import { sendSignal, signalSocket } from "./webrtc-common.js";

const image = document.querySelector("#remoteImage");
const status = document.querySelector("#status");
const tiltButton = document.querySelector("#tiltMode");
let socket;
let reconnectTimer;
let repeatTimer;
let manualClearTimer;
let orientationWatchdog;
let orientationSeen = false;
let manualCommand = null;
let tiltEnabled = false;
let neutralBeta = null;
let neutralGamma = null;
let lastTurnCommand = "stop";
let firstFrameSeen = false;

function connect() {
  clearTimeout(reconnectTimer);
  socket = signalSocket("operator", handleSignal);
  socket.onopen = () => { status.textContent = "Ожидание носителя…"; };
  socket.onclose = () => {
    status.textContent = "Сеть изменилась — переподключение…";
    firstFrameSeen = false;
    reconnectTimer = setTimeout(connect, 1500);
  };
}

connect();

function handleSignal(message) {
  if (message.type === "peer-ready") {
    status.textContent = firstFrameSeen ? "Подключено — управление готово" : "Носитель подключён, ждём камеру…";
    sendSignal(socket, { type: "operator-ready" });
  }
  if (message.type === "frame" && message.data) {
    image.src = message.data;
    if (!firstFrameSeen) {
      firstFrameSeen = true;
      status.textContent = "Подключено — управление готово";
    }
  }
  if (message.type === "peer-left") {
    status.textContent = "Носитель отключился";
    firstFrameSeen = false;
    image.removeAttribute("src");
  }
}

function sendCommand(command, source = "manual") {
  if (socket?.readyState !== WebSocket.OPEN) {
    status.textContent = "Переподключение к серверу…";
    return;
  }
  sendSignal(socket, { type: "command", command, source });
}

function stopManual() {
  clearInterval(repeatTimer);
  repeatTimer = undefined;
  clearTimeout(manualClearTimer);
  manualCommand = null;
  manualClearTimer = setTimeout(() => {
    sendCommand(tiltEnabled ? lastTurnCommand : "stop", tiltEnabled ? "gyro" : "manual");
  }, 1400);
}

document.querySelectorAll(".move").forEach((button) => {
  const begin = (event) => {
    event.preventDefault();
    clearInterval(repeatTimer);
    clearTimeout(manualClearTimer);
    manualCommand = button.dataset.command;
    sendCommand(manualCommand, "manual");
    repeatTimer = setInterval(() => sendCommand(manualCommand, "manual"), 350);
  };
  button.addEventListener("pointerdown", begin);
  button.addEventListener("pointerup", stopManual);
  button.addEventListener("pointercancel", stopManual);
  button.addEventListener("pointerleave", stopManual);
});
window.addEventListener("pointerup", () => manualCommand && stopManual());

tiltButton.onclick = async () => {
  const OrientationEvent = window.DeviceOrientationEvent;
  if (!OrientationEvent) {
    status.textContent = "Гироскоп недоступен. Откройте ссылку в Chrome или Safari";
    return;
  }
  if (typeof OrientationEvent.requestPermission === "function") {
    const permission = await OrientationEvent.requestPermission();
    if (permission !== "granted") {
      status.textContent = "Разрешите доступ к движению телефона";
      return;
    }
  }
  tiltEnabled = !tiltEnabled;
  clearTimeout(orientationWatchdog);
  orientationSeen = false;
  neutralBeta = null;
  neutralGamma = null;
  lastTurnCommand = "stop";
  tiltButton.classList.toggle("active", tiltEnabled);
  tiltButton.textContent = tiltEnabled ? "📱 Повороты включены" : "📱 Включить повороты";
  status.textContent = tiltEnabled
    ? "Держите телефон ровно 1 секунду, затем поворачивайте"
    : "Повороты гироскопом выключены";
  if (tiltEnabled) {
    orientationWatchdog = setTimeout(() => {
      if (!orientationSeen) {
        status.textContent = "Датчик не отвечает — откройте ссылку во внешнем Chrome или Safari";
        tiltEnabled = false;
        tiltButton.classList.remove("active");
        tiltButton.textContent = "📱 Включить повороты";
      }
    }, 3000);
  }
  if (!manualCommand) sendCommand("stop", "gyro");
};

window.addEventListener("deviceorientation", ({ beta, gamma }) => {
  if (!tiltEnabled || beta == null || gamma == null) return;
  orientationSeen = true;
  clearTimeout(orientationWatchdog);
  if (neutralBeta == null || neutralGamma == null) {
    neutralBeta = beta;
    neutralGamma = gamma;
    return;
  }
  const deltaBeta = beta - neutralBeta;
  const deltaGamma = gamma - neutralGamma;
  const angle = screen.orientation?.angle ?? window.orientation ?? 0;
  let vertical = deltaBeta;
  let horizontal = deltaGamma;
  if (Math.abs(angle) === 90) {
    horizontal = angle === 90 ? deltaBeta : -deltaBeta;
    vertical = angle === 90 ? -deltaGamma : deltaGamma;
  }
  const deadZone = 9;
  let command = "stop";
  if (Math.abs(horizontal) > Math.abs(vertical) && Math.abs(horizontal) > deadZone) {
    command = horizontal > 0 ? "turn_right" : "turn_left";
  } else if (Math.abs(vertical) > deadZone) {
    command = vertical > 0 ? "tilt_down" : "tilt_up";
  }
  if (command !== lastTurnCommand) {
    lastTurnCommand = command;
    if (!manualCommand) sendCommand(command, "gyro");
  }
});

window.Telegram?.WebApp?.expand();
