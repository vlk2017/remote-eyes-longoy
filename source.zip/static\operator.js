import { rtcConfig, sendSignal, signalSocket } from "./webrtc-common.js";

const video = document.querySelector("#remoteVideo");
const status = document.querySelector("#status");
const tiltButton = document.querySelector("#tiltMode");
const socket = signalSocket("operator", handleSignal);
let peer;
let channel;
let pendingIce = [];
let repeatTimer;
let manualCommand = null;
let tiltEnabled = false;
let neutralBeta = null;
let neutralGamma = null;
let lastTurnCommand = "stop";

async function handleSignal(message) {
  if (message.type === "offer") {
    peer?.close();
    peer = new RTCPeerConnection(rtcConfig);
    pendingIce = [];
    channel = peer.createDataChannel("directions");
    channel.onopen = () => { status.textContent = "Подключено — управление готово"; };
    channel.onclose = () => { status.textContent = "Канал управления закрыт"; };
    peer.ontrack = ({ streams }) => {
      video.srcObject = streams[0];
      video.play().catch(() => {});
    };
    peer.onicecandidate = ({ candidate }) =>
      candidate && sendSignal(socket, { type: "ice", candidate });
    peer.onconnectionstatechange = () => {
      status.textContent = peer.connectionState === "connected"
        ? "Подключено — управление готово"
        : `Связь: ${peer.connectionState}`;
    };
    await peer.setRemoteDescription(message.sdp);
    for (const candidate of pendingIce.splice(0)) await peer.addIceCandidate(candidate);
    await peer.setLocalDescription(await peer.createAnswer());
    sendSignal(socket, { type: "answer", sdp: peer.localDescription });
  }
  if (message.type === "ice" && peer) {
    if (peer.remoteDescription) await peer.addIceCandidate(message.candidate);
    else pendingIce.push(message.candidate);
  }
  if (message.type === "peer-left") status.textContent = "Носитель отключился";
}

function sendCommand(command, source = "manual") {
  if (channel?.readyState !== "open") {
    status.textContent = "Сначала дождитесь подключения носителя";
    return;
  }
  channel.send(JSON.stringify({ command, source }));
}

function stopManual() {
  clearInterval(repeatTimer);
  repeatTimer = undefined;
  manualCommand = null;
  sendCommand(tiltEnabled ? lastTurnCommand : "stop", tiltEnabled ? "gyro" : "manual");
}

document.querySelectorAll(".move").forEach((button) => {
  const begin = (event) => {
    event.preventDefault();
    clearInterval(repeatTimer);
    manualCommand = button.dataset.command;
    sendCommand(manualCommand, "manual");
    repeatTimer = setInterval(() => sendCommand(manualCommand, "manual"), 250);
  };
  button.addEventListener("pointerdown", begin);
  button.addEventListener("pointerup", stopManual);
  button.addEventListener("pointercancel", stopManual);
  button.addEventListener("pointerleave", stopManual);
});
window.addEventListener("pointerup", () => manualCommand && stopManual());

tiltButton.onclick = async () => {
  const OrientationEvent = window.DeviceOrientationEvent;
  if (!OrientationEvent) {
    status.textContent = "Гироскоп недоступен. Откройте ссылку в Chrome или Safari";
    return;
  }
  if (typeof OrientationEvent.requestPermission === "function") {
    const permission = await OrientationEvent.requestPermission();
    if (permission !== "granted") {
      status.textContent = "Разрешите доступ к движению телефона";
      return;
    }
  }
  tiltEnabled = !tiltEnabled;
  neutralBeta = null;
  neutralGamma = null;
  lastTurnCommand = "stop";
  tiltButton.classList.toggle("active", tiltEnabled);
  tiltButton.textContent = tiltEnabled ? "📱 Повороты включены" : "📱 Включить повороты";
  status.textContent = tiltEnabled
    ? "Держите телефон ровно 1 секунду, затем поворачивайте"
    : "Повороты гироскопом выключены";
  if (!manualCommand) sendCommand("stop", "gyro");
};

window.addEventListener("deviceorientation", ({ beta, gamma }) => {
  if (!tiltEnabled || beta == null || gamma == null) return;
  if (neutralBeta == null || neutralGamma == null) {
    neutralBeta = beta;
    neutralGamma = gamma;
    return;
  }
  const deltaBeta = beta - neutralBeta;
  const deltaGamma = gamma - neutralGamma;
  const angle = screen.orientation?.angle ?? window.orientation ?? 0;
  let vertical = deltaBeta;
  let horizontal = deltaGamma;
  if (Math.abs(angle) === 90) {
    horizontal = angle === 90 ? deltaBeta : -deltaBeta;
    vertical = angle === 90 ? -deltaGamma : deltaGamma;
  }
  const deadZone = 9;
  let command = "stop";
  if (Math.abs(horizontal) > Math.abs(vertical) && Math.abs(horizontal) > deadZone) {
    command = horizontal > 0 ? "turn_right" : "turn_left";
  } else if (Math.abs(vertical) > deadZone) {
    command = vertical > 0 ? "tilt_down" : "tilt_up";
  }
  if (command !== lastTurnCommand) {
    lastTurnCommand = command;
    if (!manualCommand) sendCommand(command, "gyro");
  }
});

window.Telegram?.WebApp?.expand();
