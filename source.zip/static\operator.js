import { rtcConfig, sendSignal, signalSocket } from "./webrtc-common.js";

const video = document.querySelector("#remoteVideo");
const status = document.querySelector("#status");
const socket = signalSocket("operator", handleSignal);
let peer;
let channel;
let repeatTimer;
let tiltEnabled = false;
let lastTiltDirection = "stop";

async function handleSignal(message) {
  if (message.type === "offer") {
    peer?.close();
    peer = new RTCPeerConnection(rtcConfig);
    channel = peer.createDataChannel("directions");
    channel.onopen = () => { status.textContent = "Подключено"; };
    channel.onclose = () => { status.textContent = "Канал управления закрыт"; };
    peer.ontrack = ({ streams }) => { video.srcObject = streams[0]; video.play().catch(() => {}); };
    peer.onicecandidate = ({ candidate }) => candidate && sendSignal(socket, { type: "ice", candidate });
    peer.onconnectionstatechange = () => { status.textContent = peer.connectionState === "connected" ? "Подключено" : `Связь: ${peer.connectionState}`; };
    await peer.setRemoteDescription(message.sdp);
    await peer.setLocalDescription(await peer.createAnswer());
    sendSignal(socket, { type: "answer", sdp: peer.localDescription });
  }
  if (message.type === "ice" && peer) await peer.addIceCandidate(message.candidate);
  if (message.type === "peer-left") status.textContent = "Носитель отключился";
}

function sendDirection(direction) {
  if (channel?.readyState === "open") channel.send(JSON.stringify({ direction }));
}

function stop() {
  clearInterval(repeatTimer);
  repeatTimer = undefined;
  sendDirection("stop");
}

document.querySelectorAll(".arrow").forEach((button) => {
  const begin = (event) => {
    event.preventDefault();
    stop();
    const direction = button.dataset.direction;
    sendDirection(direction);
    repeatTimer = setInterval(() => sendDirection(direction), 150);
  };
  button.addEventListener("pointerdown", begin);
  button.addEventListener("pointerup", stop);
  button.addEventListener("pointercancel", stop);
  button.addEventListener("pointerleave", stop);
});

window.addEventListener("pointerup", stop);
document.querySelector("#tiltMode").onclick = async (event) => {
  if (typeof DeviceOrientationEvent?.requestPermission === "function") {
    const permission = await DeviceOrientationEvent.requestPermission();
    if (permission !== "granted") return;
  }
  tiltEnabled = !tiltEnabled;
  event.currentTarget.classList.toggle("active", tiltEnabled);
  event.currentTarget.textContent = tiltEnabled ? "📱 Наклон включён" : "📱 Управлять наклоном";
  if (!tiltEnabled) {
    lastTiltDirection = "stop";
    sendDirection("stop");
  }
};

window.addEventListener("deviceorientation", ({ beta, gamma }) => {
  if (!tiltEnabled || beta == null || gamma == null) return;
  const deadZone = 12;
  let direction = "stop";
  if (Math.abs(gamma) > Math.abs(beta) && Math.abs(gamma) > deadZone) {
    direction = gamma > 0 ? "right" : "left";
  } else if (Math.abs(beta) > deadZone) {
    direction = beta > 0 ? "down" : "up";
  }
  if (direction !== lastTiltDirection) {
    lastTiltDirection = direction;
    sendDirection(direction);
  }
});
window.Telegram?.WebApp?.expand();
